
int __errno_location;
