

extern char serial_in_byte(void);
char inbyte(void)
{
	return serial_in_byte();
}

extern void serial_out_byte(char ch);
void outbyte(char chr)
{
	return serial_out_byte(chr);
}


/* from mips sim interp.c
 * void get_mem_info(unsigned int *ptr)
 * in:  A0 = pointer to three word memory location 
 * out: [A0 + 0] = size 
 *      [A0 + 4] = instruction cache size 
 *      [A0 + 8] = data cache size 
 */
extern unsigned int __stack;
void get_mem_info(unsigned int *ptr)
{
	if(__stack) {
		ptr[0] = __stack - 0x80100000;
	} 
	else
		ptr[0] = 0x800000; // 32MB
	ptr[1] = 0x4000; // 16k
	ptr[2] = 0x4000; // 16k
}


#include <sys/time.h>
extern int sys_gettimeofday(struct timeval *tv,struct timezone *tz);
int gettimeofday(struct timeval *tv,struct timezone *tz)
{
	return sys_gettimeofday(tv,tz);
}
extern time_t sys_time(time_t *t);
time_t time(time_t *t)
{
	return sys_time(t);
}
