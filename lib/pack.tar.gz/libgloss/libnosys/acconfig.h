/* Name of package.  */
#undef PACKAGE

/* Version of package.  */
#undef VERSION

/* Missing syscall names */
#undef MISSING_SYSCALL_NAMES

/* Using ELF format */
#undef HAVE_ELF

/* Using GNU LD */
#undef HAVE_GNU_LD

/* .previous directive allowed */
#undef HAVE_ASM_PREVIOUS_DIRECTIVE

/* .pushsection/.popsection directives allowed */
#undef HAVE_ASM_POPSECTION_DIRECTIVE

/* symbol prefix */
#undef __SYMBOL_PREFIX
