
#if 1

#define _AND ,
#define _DEFUN(name,arglist,photo) name(photo)

#else

#define _AND ;
#define _DEFUN(name,arg,dec) \
	name arg	     \
	dec;

#endif
